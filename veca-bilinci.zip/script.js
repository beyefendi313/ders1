// --- SİBERNETİK SİMÜLASYON VERİLERİ ---
const simulationSteps = [
    {
        title: "HAZIRLIK & KALKAN",
        text: "Rahat bir pozisyona geç. Derin bir nefes al. Şimdi etrafında Altın renkte bir koruma kalkanı imgele. Güvendesin.",
        color: "#ffd700", // Gold
        duration: 5000
    },
    {
        title: "ADIM 1: NİYET",
        text: "'Ben şu an, Yüce Yaratıcı'nın izniyle, tüm varlığımla şifalanmaya, arınmaya ve yükselmeye niyet ediyorum.'",
        color: "#ffffff",
        duration: 6000
    },
    {
        title: "ADIM 2: İLAHİ NUR",
        text: "Başının üzerinden bembeyaz bir ışığın (İlahi Nur) girdiğini ve tüm bedenini yıkadığını hisset. 'İlahi Nur Enerji Alanı AÇIK.'",
        color: "#00f3ff", // Cyan
        duration: 8000
    },
    {
        title: "ADIM 3: 4. BOYUTA YÜKSELİŞ",
        text: "Şimdi frekansını yükseltiyorsun. '3. Boyuttan 4. Boyuta yükseliyorum. Bana ait olmayan tüm tortular dökülsün.'",
        color: "#bc13fe", // Purple
        duration: 8000
    },
    {
        title: "ADIM 4: NEGATİF KESİMİ",
        text: "Sırtında, omuriliğinde veya zihninde ağırlık yapan her türlü kancanın, halatın şimdi kesildiğini imgele. 'Özgürüm.'",
        color: "#ff3333", // Red/Cleanse
        duration: 7000
    },
    {
        title: "ADIM 5: ALTIN ALEV",
        text: "'Altın Alev Enerji Alanı AÇIK.' Kalbinden yayılan altın sarısı bir ışığın tüm auranı kapladığını gör.",
        color: "#ffd700",
        duration: 8000
    },
    {
        title: "ADIM 6: SİBERNETİK AKTİVASYON",
        text: "Kendi ismini içinden söyle. '... kodlu potansiyel enerjim şimdi aktif olsun ve bedenime entegre olsun.'",
        color: "#00ff88", // Green/Active
        duration: 8000
    },
    {
        title: "SONUÇ: ŞÜKÜR VE MÜHÜRLEME",
        text: "Bu çalışma tüm zamanlarda ve boyutlarda geçerli olsun. Şükürler olsun. (Gözlerini yavaşça açabilirsin).",
        color: "#ffffff",
        duration: 0 // Son adım
    }
];

// --- SİMÜLASYON MANTIĞI ---
let currentStep = 0;
const instructionText = document.getElementById('instruction-text');
const shieldDisplay = document.getElementById('shieldDisplay');
const progressBar = document.getElementById('simBar');
const nextBtn = document.getElementById('nextBtn');
const startBtn = document.getElementById('startBtn');
const root = document.documentElement;

function scrollToSim() {
    document.getElementById('simulation-zone').scrollIntoView({ behavior: 'smooth' });
}

function startSimulation() {
    startBtn.style.display = 'none';
    nextBtn.classList.remove('hidden');
    shieldDisplay.classList.add('active');
    loadStep(0);
}

function nextStep() {
    if (currentStep < simulationSteps.length - 1) {
        currentStep++;
        loadStep(currentStep);
    } else {
        // Reset
        instructionText.innerHTML = "Çalışma Tamamlandı. Işıkla Kalın.";
        nextBtn.innerHTML = "Tekrarla";
        nextBtn.onclick = function() { location.reload(); };
    }
}

function loadStep(index) {
    const step = simulationSteps[index];
    
    // Metin ve Renk Güncelleme
    instructionText.style.opacity = 0;
    setTimeout(() => {
        instructionText.innerHTML = `<strong style="display:block; font-size:0.8em; color:${step.color}; margin-bottom:10px;">${step.title}</strong>${step.text}`;
        instructionText.style.opacity = 1;
        
        // Kalkan rengini değiştir
        root.style.setProperty('--neon-cyan', step.color);
    }, 500);

    // Progress Bar
    const progress = ((index + 1) / simulationSteps.length) * 100;
    progressBar.style.width = `${progress}%`;
    progressBar.style.backgroundColor = step.color;
}

// --- STANDART GÖRSEL EFEKTLER ---
// Intersection Observer (Kaydırma Animasyonları)
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.slide-up').forEach((el) => observer.observe(el));

// Canvas Parçacık Efekti (Arkaplan)
const canvas = document.getElementById('neuro-canvas');
const ctx = canvas.getContext('2d');
let width, height, particles = [];

function resize() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
}
window.addEventListener('resize', resize);
resize();

class Particle {
    constructor() {
        this.reset();
    }
    reset() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.5) * 0.3;
        this.vy = (Math.random() - 0.5) * 0.3;
        this.size = Math.random() * 2;
        this.alpha = Math.random() * 0.5 + 0.1;
    }
    update() {
        this.x += this.vx; this.y += this.vy;
        if (this.x < 0 || this.x > width || this.y < 0 || this.y > height) this.reset();
    }
    draw() {
        ctx.fillStyle = `rgba(188, 19, 254, ${this.alpha})`;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
    }
}

for (let i = 0; i < 40; i++) particles.push(new Particle());

function animate() {
    ctx.clearRect(0, 0, width, height);
    particles.forEach(p => {
        p.update();
        p.draw();
    });
    // Bağlantı çizgileri
    particles.forEach((p1, index) => {
        for(let j = index + 1; j < particles.length; j++) {
            const p2 = particles[j];
            const d = Math.hypot(p1.x - p2.x, p1.y - p2.y);
            if (d < 100) {
                ctx.strokeStyle = `rgba(188, 19, 254, ${0.1 - d/1000})`;
                ctx.lineWidth = 0.5;
                ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();
            }
        }
    });
    requestAnimationFrame(animate);
}
animate();