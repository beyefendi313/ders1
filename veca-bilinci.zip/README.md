# Sibernetik Işık Aktivasyonları — Demo Projesi

> Basit statik web sitesi: `index.html`, `style.css`, `script.js` içerir. Bu proje yerel olarak çalıştırılmak ve GitHub gibi uzak depolara push edilmek üzere hazırlanmıştır.

## İçerik
- `index.html` — Sayfa HTML yapısı ve `script.js`/`style.css` bağlantıları.
- `style.css` — Tasarım ve animasyon stilleri.
- `script.js` — Simülasyon adımları, canvas parçacık efekti ve kontrol mantığı.

## Hızlı Başlat (PowerShell)
1. Proje klasörüne gidin:

```powershell
cd "d:\VS Projelerim"
```

2. Python ile basit HTTP sunucu başlatın (Python yüklüyse):

```powershell
python -m http.server 8000
```

Tarayıcınızda `http://localhost:8000` adresini açın.

Alternatif (Node.js yüklüyse):

```powershell
npx http-server -p 8000
```

## Git / Yayına Alma
1. Yerel repo başlat:

```powershell
cd "d:\VS Projelerim"
git init
git add .
git commit -m "İlk commit — proje yayına hazır"
```

2. GitHub üzerinde yeni bir repo oluşturduktan sonra (ör. `veca-bilinci`), uzaktaki repoyu ekleyip push edin:

```powershell
git remote add origin https://github.com/<kullanici>/<repo>.git
git branch -M main
git push -u origin main
```

> Not: GitHub erişimi/otomatik push isterseniz erişim token veya `gh` CLI bilgilerini sağlamalısınız.

## Lisans ve Telif
Bu demo proje örnek içerik içerir. Eğer dış kaynaklardan görsel veya animasyon indirecekseniz telif haklarına dikkat edin.

## İletişim
Projeyi çalıştırmamı veya GitHub'a push etmemi isterseniz hangi adımları otomatik yapmamı istediğinizi söyleyin.
